// src/components/Loading.jsx
import React from 'react';

function Loading() {
  return (
    <div className="loading">
      <div className="typing-indicator">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  );
}

export default Loading;
